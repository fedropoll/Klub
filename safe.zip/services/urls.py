from rest_framework.routers import DefaultRouter
from .views import ServiceViewSet, CategoryViewSet

router = DefaultRouter()
router.register('services', ServiceViewSet, basename='services')
router.register('categories', CategoryViewSet, basename='categories')

urlpatterns = router.urls
